import React from 'react';
const ScoreLabel = props => (
    <div><h1>current score</h1>
    <h1>{props.score}</h1>
    </div>
)
export default ScoreLabel;